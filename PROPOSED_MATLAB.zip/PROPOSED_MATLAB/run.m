% MoRF prediction algorithm 
%(Proposed terminal and middle region models scores combined with scores of
% predictors MoRFpred-plus, PROMIS, and MoRFchibi)
%
% Input
% HSE file predicted by SPIDER2 
% MoRFpred-plus output score file  ()
% OPAL output score file (To get score of PROMIS)
% MoRFchibi output score file
%
% Output
% MoRFscore: scores for each residue of the query sequence
%
% Ronesh Sharma, FNU, Fiji. 
% Email: sharmaronesh@yahoo.com
% Ref. Sharma et al., , 2018

clear all;
close all;

addpath('F:\phd\General_Programs_final\libsvm-3.21\matlab');
addpath('input');

%data
seq1 = fastaread('input.fasta'); %load seq file
seq =seq1.Sequence;
HESa1 = importdata('input.hsa2'); %load hsa2 file
sp_hsa2= HESa1.data;
%HESb1 = importdata('input.hsb2'); %load hsb2 file
%sp_hsb2 = HESb1.data;
%spd31 = importdata('input.spd3'); %load spd3 file
%sp_spd3= spd31.data;

%scores of other predictors
MoRFpred_plus_score_ = importdata('scores_MoRFpred_plus.txt'); %load MoRFpred-plus score
MoRFpred_plus_score= MoRFpred_plus_score_.data;

MoRFchibi_score_ = importdata('output_MoRFchibi.txt'); %load MoRFchibi score
MoRFchibi_score= MoRFchibi_score_.data;

PROMIS_score_ = importdata('Scores_OPAL.txt'); %load PROMIS score
PROMIS_score= PROMIS_score_.data;

%Predict using proposed model
profile_windows_m_1 = [sp_hsa2(:,2)/100 ] ; %HSE attribute (2)
ab=0;
hh=size(profile_windows_m_1,1); % check if proetin length less than total Flanking size
FF=42;
if hh <FF
    ab=1;
    profile_windows_m1 =[zeros(round((FF-hh)/2),size(profile_windows_m_1,2)); profile_windows_m_1 ; zeros(round((FF-hh)/2),size(profile_windows_m_1,2))]; 
else
    profile_windows_m1 = profile_windows_m_1;
end
MoRFscores_m1_wn = test_windows_method_2_models_start_end(profile_windows_m1);
if ab==1
     MoRFscores_wn = MoRFscores_m1_wn(round((FF-hh)/2)+1:end-round((FF-hh)/2),:) ;
else
     MoRFscores_wn = MoRFscores_m1_wn;
end
MoRFwin_1=MoRFscores_wn; %proposed model

%Process Scores
Proposed_P = Process_score_se(MoRFwin_1,12); %Process scores of proposed model
MoRFpred_plus_P = Process_score_se(MoRFpred_plus_score(:,3),4); %Process scores of MoRFpred_plus
MoRFchibi_P = Process_score_se(MoRFchibi_score(:,1),15); %Process scores of MoRFchibi
PROMIS = PROMIS_score(:,2); %Scores of PROMIS

Proposedcombined= (Proposed_P+ MoRFpred_plus_P+MoRFchibi_P+PROMIS)/4; %Combine scores 
Proposedcombined_P = Process_score_se(Proposedcombined,8); %Process combined scores


fileID = fopen('Ouput_scores.txt','w');  % save scores in txt file scores.txt
fprintf(fileID,'%3s  %3s  %20s  \n','No:', 'residues','Proposed Method' );
for rry=1:size(Proposedcombined_P,1)
fprintf(fileID,'%0.1f  %3s  %f \n',rry,seq(rry),Proposedcombined_P(rry,1)  );
end
fclose(fileID);



