function [AC] = Auto_Cov(mat)
for Kk1=1:10
    for Kk2=1:size(mat,1)-Kk1
    Occc5(Kk2,:) = (((mat(Kk2,:)) .* (mat(Kk2+Kk1,:))));
    end
Occ5(Kk1,:)= roundn((sum(Occc5,1))/size(mat,1),-2);
Occc5=[];

end
OOP=Occ5(1:end,:);
OC5 = OOP(:)';
AC=OC5;
end
