function MoRFscores = test_windows_method_2_models_start_end(profile)
%
% Input
% Profile
%
% Output
% MoRFscore: scores for each residue of the query sequence
%
% Ronesh Sharma, FNU, Fiji. 
% Email: sharmaronesh@yahoo.com
% Ref. Sharma et al., , 2018

load SVM_model_win_xx_se; %load trained models
load SVM_model_win_xx_mid; %load trained models

%--------------------------------------------------------------------------
kk=1;win_flank_siz= 20;  mat4=profile ;T_len=size(mat4,1);colm=size(profile,2);
win_flank_siz_se= 20; 
win_flank_siz_mid= 20; 
kkz1=1;kkz2=1;kkz3=1;
 for e=1:T_len
    %mf_1=zeros(((win_flank_siz*2)+1),size(mat4,2)); 
    % mf_2=zeros(((win_flank_siz*2)+1),size(mat4,2)); 
    if e<win_flank_siz+1 % seq at start
        %%{
        if e<win_flank_siz_se+1
        regs = mat4(1:e+win_flank_siz_se,:);
       % sample_d_s = [ zeros(win_flank_siz_se-(e-1),colm); regs  ]; % flank zeros at start
        sample_d_s = [ regs  ]; % empty
        else
        regs = mat4(e-win_flank_siz_se:e+win_flank_siz_se,:);
        sample_d_s = [ regs  ]; % flank zeros at start  
        end
        %%}
            %Auto_CV
        feature_pp_s(kkz1,:)=  Auto_Cov(sample_d_s); kkz1=kkz1+1;
    elseif e> T_len-win_flank_siz %seq at end
        %%{
        if e>T_len-win_flank_siz_se
        rege = mat4(e-win_flank_siz_se:end,:); % chec later removing 1 for now 
        sample_d_e = [ rege  ]; % empty
        else
         rege = mat4(e-win_flank_siz_se:e+win_flank_siz_se,:); 
        sample_d_e = [ rege  ]; % flank zeros at end
        end
        %%}
        %Auto_CV
        feature_pp_e(kkz3,:)=  Auto_Cov(sample_d_e); kkz3=kkz3+1;
         
    else % seq in middle
      sample_d_mid= mat4(e-win_flank_siz_se:e+win_flank_siz_se,:);
      %win
       feature_pp_mid(kkz2,:)=  sample_d_mid(:)'; kkz2=kkz2+1;
        
    end
 end
mat4=[];
%-------------------------------------------------------------------------
% Predict and combine scores 
[predict_label_L, accuracy_L1, dec_values_s] = svmpredict( ones(size(feature_pp_s,1),1), feature_pp_s, SVM_model_win_xx_se,['-q -b 1']);
[predict_label_L, accuracy_L1, dec_values_mid] = svmpredict( ones(size(feature_pp_mid,1),1), feature_pp_mid, SVM_model_win_xx_mid,['-q -b 1']);
[predict_label_L, accuracy_L1, dec_values_e] = svmpredict( ones(size(feature_pp_e,1),1), feature_pp_e, SVM_model_win_xx_se,['-q -b 1']);

MoRFscores = [ dec_values_s(:,1); dec_values_mid(:,1) ;dec_values_e(:,1) ] ;
end
%##############################
