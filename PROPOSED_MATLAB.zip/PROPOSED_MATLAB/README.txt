The given codes are tested using MATLAB (will work on both windows and UNIX system)

Software requirements:
-The provided package requires MATLAB software (version 2015 and above)
-LibSVM tool box


Input
input query sequence file (input.fasta)
HSE file (obtained by SPIDER2 predictor) (input.hsa2)
MoRFpred-plus output score file  (obtained by MoRFpred-plus predictor) (scores_MoRFpred_plus.txt)
PROMIS output score file (obtained by PROMIS predictor) (Scores_OPAL.txt)
MoRFchibi output score file (obtained by MoRFchibi predictor) (output_MoRFchibi.txt)

Output
MoRFscore: scores for each residue of the query sequence predicted by proposed model (Ouput_scores.txt)

Usage:
To use the provided package:
-MATLAB and the required tool box should be installed
-All the input files relating to the query sequence file much be provided in the input folder
-path to LibSVM should be adjusted in run.m file
-Simulate run.m file to get the output score file (Ouput_scores.txt)
-A demo query sequence file with other demo input files are available in the input folder

Ronesh Sharma, FNU, Fiji. 
Email: sharmaronesh@yahoo.com
Ref. Sharma et al., , 2018